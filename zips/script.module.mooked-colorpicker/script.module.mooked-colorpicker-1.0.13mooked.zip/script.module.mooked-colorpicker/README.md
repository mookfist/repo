# ColorPicker Dialog
### script.module.colorpicker

This is a reusable dialog to pick colors.

This code is based on v1.0.12 of script.skin.helper.colorpicker available at https://github.com/marcelveldt/script.skin.helper.colorpicker. It was forked because the original colorpicker was more built to support skins specifically. It exposed a set of actions but what was more convenient was to be able to import the Dialog class directly in my code.

This addon is not part of the official Kodi repo

