import os, sys
import xbmc

from qbittorent.client import Client

xbmc.log('imported the client properly!')

