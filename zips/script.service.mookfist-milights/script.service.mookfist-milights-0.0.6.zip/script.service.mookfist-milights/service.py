from light import Lights
import xbmc, xbmcaddon
import time
import json

__scriptname__ = "Mookfist Milights"
__author__     = "Mookfist"
__url__        = "https://github.com/mookfist/repo"
__settings__   = xbmcaddon.Addon(id='script.service.mookfist-milights')
__version__    = __settings__.getAddonInfo('version')
__language__   = __settings__.getLocalizedString

'''
class MyPlayer(xbmc.Player):
  def __init__(self, lights):
    xbmc.Player.__init__(self)
    self.lights = lights

  def onPlayBackPaused(self):
    time.sleep(5)
    self.lights.fadeOn()

  def onPlayBackStarted(self):
    if self.isPlayingVideo():
      tag = self.getVideoInfoTag()
      print "------------ TAG INFO ----------------"
      print tag.getFirstAired()
      print tag.getPremiered()
      print "--------------------------------------"
      self.lights.fadeOff()    

  def onPlayBackStopped(self):
    self.lights.fadeOn()
'''    


class MyMonitor(xbmc.Monitor):

  def __init__(self, lights):
    xbmc.Monitor.__init__(self)
    self.lights = lights


  def _getPlayerType(self, data):
    if data['item']['type'] == 'episode':
      return 'tv'
    elif data['item']['type'] == 'movie':
      return 'movie'
    else:
      return None


  def _onPlay(self, data):
    playerType = self._getPlayerType(data)

    if playerType == None:
      xbmc.log('Could not determine player type: %s' % data, xbmc.LOGWARNING)
      return

    if playerType == 'tv' and __settings__.getSetting('tv_enabled') == True:
      self.lights.fadeOff()
    elif playerType == 'movie' and __settings__.getSetting('movie_enabled') == True:
      self.lights.fadeOff()

  def _onStop(self, data):
    playerType = self._getPlayerType(data)

    if playerType == None:
      xbmc.log('Coult not determine player type: %s' % data, xbmc.LOGWARNING)
      return

    if playerType == 'tv' and __settings__.getSetting('tv_enabled') == True:
      self.lights.fadeOn()
    elif playerType == 'movie' and __settings__.getSetting('movie_enabled') == True:
      self.lights.fadeOn()


  def onNotification(self, sender, method, data):

    data = json.loads(data)

    if sender == "xbmc" and method == "Player.OnPlay":
      self._onPlay(data)
    elif sender == "xbmc" and method == "Player.OnStop":
      self._onStop(data)
      
    print "SENDER: %s --- METHOD %s --- DATA %s" % (sender, method, data)


if __name__ == "__main__":

  l = Lights(__settings__.getSetting('light_host'))
  l.group = int(__settings__.getSetting('light_group'))

  monitor = MyMonitor(lights=l)
#  player = MyPlayer(lights=l)

  while not monitor.abortRequested():
    if monitor.waitForAbort(10):
      break

    
