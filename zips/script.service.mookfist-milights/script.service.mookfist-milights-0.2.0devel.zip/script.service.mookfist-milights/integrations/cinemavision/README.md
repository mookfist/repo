Mookfist Milights Cinemavision Integration
==========================================

These example action files are what I use to control my lights from CinemaVision.

In order for this to work properly, you must disable Movies in the mookfist-milights configuration.
