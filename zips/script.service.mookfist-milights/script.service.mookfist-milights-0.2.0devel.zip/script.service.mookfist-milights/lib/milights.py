from mookfist_lled_controller.bridges.ver4 import get_bridge as get_bridge_v4
from mookfist_lled_controller.bridges.ver6 import get_bridge as get_bridge_v6
import time

def scan_v4():

  b4 = get_bridge_v4()
  b6 = get_bridge_v6()

  print b4
  print b6

for i in range(0,5):
  time.sleep(0.5)
  scan_v4()
