mookfist-milights Kodi Addon
============================

This addon is for controlling LimitlessLED-based lights (including Milights).


Configuration
=============


General Settings
  Host  -  host name of the wifi adapater
  Port  -  port number of the adapter
  Command Delay - Milliseconds to wait inbetween sending commands

