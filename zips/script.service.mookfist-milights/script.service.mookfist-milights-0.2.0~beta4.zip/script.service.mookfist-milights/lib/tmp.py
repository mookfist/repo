a = {1: 'a', 2: 'b', 'all': 'c'}

for x in a:
  print(a[x])
