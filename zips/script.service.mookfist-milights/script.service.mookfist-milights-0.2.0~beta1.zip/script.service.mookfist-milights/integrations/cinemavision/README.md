Mookfist Milights Cinemavision Integration
==========================================

These are example files showing how you can use CinemaVision action files to controller the Mookfist Milights plugin.

